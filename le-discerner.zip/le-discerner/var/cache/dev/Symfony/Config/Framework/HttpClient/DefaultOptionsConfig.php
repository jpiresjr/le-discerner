<?php

namespace Symfony\Config\Framework\HttpClient;

require_once __DIR__.\DIRECTORY_SEPARATOR.'DefaultOptions'.\DIRECTORY_SEPARATOR.'PeerFingerprintConfig.php';
require_once __DIR__.\DIRECTORY_SEPARATOR.'DefaultOptions'.\DIRECTORY_SEPARATOR.'RetryFailedConfig.php';

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class DefaultOptionsConfig 
{
    private $headers;
    private $vars;
    private $maxRedirects;
    private $httpVersion;
    private $resolve;
    private $proxy;
    private $noProxy;
    private $timeout;
    private $maxDuration;
    private $bindto;
    private $verifyPeer;
    private $verifyHost;
    private $cafile;
    private $capath;
    private $localCert;
    private $localPk;
    private $passphrase;
    private $ciphers;
    private $peerFingerprint;
    private $cryptoMethod;
    private $extra;
    private $rateLimiter;
    private $retryFailed;
    private $_usedProperties = [];

    /**
     * @return $this
     */
    public function header(string $name, mixed $value): static
    {
        $this->_usedProperties['headers'] = true;
        $this->headers[$name] = $value;

        return $this;
    }

    /**
     * @param ParamConfigurator|list<ParamConfigurator|mixed> $value
     *
     * @return $this
     */
    public function vars(ParamConfigurator|array $value): static
    {
        $this->_usedProperties['vars'] = true;
        $this->vars = $value;

        return $this;
    }

    /**
     * The maximum number of redirects to follow.
     * @default null
     * @param ParamConfigurator|int $value
     * @return $this
     */
    public function maxRedirects($value): static
    {
        $this->_usedProperties['maxRedirects'] = true;
        $this->maxRedirects = $value;

        return $this;
    }

    /**
     * The default HTTP version, typically 1.1 or 2.0, leave to null for the best version.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function httpVersion($value): static
    {
        $this->_usedProperties['httpVersion'] = true;
        $this->httpVersion = $value;

        return $this;
    }

    /**
     * @return $this
     */
    public function resolve(string $host, mixed $value): static
    {
        $this->_usedProperties['resolve'] = true;
        $this->resolve[$host] = $value;

        return $this;
    }

    /**
     * The URL of the proxy to pass requests through or null for automatic detection.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function proxy($value): static
    {
        $this->_usedProperties['proxy'] = true;
        $this->proxy = $value;

        return $this;
    }

    /**
     * A comma separated list of hosts that do not require a proxy to be reached.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function noProxy($value): static
    {
        $this->_usedProperties['noProxy'] = true;
        $this->noProxy = $value;

        return $this;
    }

    /**
     * The idle timeout, defaults to the "default_socket_timeout" ini parameter.
     * @default null
     * @param ParamConfigurator|float $value
     * @return $this
     */
    public function timeout($value): static
    {
        $this->_usedProperties['timeout'] = true;
        $this->timeout = $value;

        return $this;
    }

    /**
     * The maximum execution time for the request+response as a whole.
     * @default null
     * @param ParamConfigurator|float $value
     * @return $this
     */
    public function maxDuration($value): static
    {
        $this->_usedProperties['maxDuration'] = true;
        $this->maxDuration = $value;

        return $this;
    }

    /**
     * A network interface name, IP address, a host name or a UNIX socket to bind to.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function bindto($value): static
    {
        $this->_usedProperties['bindto'] = true;
        $this->bindto = $value;

        return $this;
    }

    /**
     * Indicates if the peer should be verified in a TLS context.
     * @default null
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function verifyPeer($value): static
    {
        $this->_usedProperties['verifyPeer'] = true;
        $this->verifyPeer = $value;

        return $this;
    }

    /**
     * Indicates if the host should exist as a certificate common name.
     * @default null
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function verifyHost($value): static
    {
        $this->_usedProperties['verifyHost'] = true;
        $this->verifyHost = $value;

        return $this;
    }

    /**
     * A certificate authority file.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function cafile($value): static
    {
        $this->_usedProperties['cafile'] = true;
        $this->cafile = $value;

        return $this;
    }

    /**
     * A directory that contains multiple certificate authority files.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function capath($value): static
    {
        $this->_usedProperties['capath'] = true;
        $this->capath = $value;

        return $this;
    }

    /**
     * A PEM formatted certificate file.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function localCert($value): static
    {
        $this->_usedProperties['localCert'] = true;
        $this->localCert = $value;

        return $this;
    }

    /**
     * A private key file.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function localPk($value): static
    {
        $this->_usedProperties['localPk'] = true;
        $this->localPk = $value;

        return $this;
    }

    /**
     * The passphrase used to encrypt the "local_pk" file.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function passphrase($value): static
    {
        $this->_usedProperties['passphrase'] = true;
        $this->passphrase = $value;

        return $this;
    }

    /**
     * A list of TLS ciphers separated by colons, commas or spaces (e.g. "RC3-SHA:TLS13-AES-128-GCM-SHA256"...)
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function ciphers($value): static
    {
        $this->_usedProperties['ciphers'] = true;
        $this->ciphers = $value;

        return $this;
    }

    /**
     * Associative array: hashing algorithm => hash(es).
     */
    public function peerFingerprint(array $value = []): \Symfony\Config\Framework\HttpClient\DefaultOptions\PeerFingerprintConfig
    {
        if (null === $this->peerFingerprint) {
            $this->_usedProperties['peerFingerprint'] = true;
            $this->peerFingerprint = new \Symfony\Config\Framework\HttpClient\DefaultOptions\PeerFingerprintConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "peerFingerprint()" has already been initialized. You cannot pass values the second time you call peerFingerprint().');
        }

        return $this->peerFingerprint;
    }

    /**
     * The minimum version of TLS to accept; must be one of STREAM_CRYPTO_METHOD_TLSv*_CLIENT constants.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function cryptoMethod($value): static
    {
        $this->_usedProperties['cryptoMethod'] = true;
        $this->cryptoMethod = $value;

        return $this;
    }

    /**
     * @param ParamConfigurator|list<ParamConfigurator|mixed> $value
     *
     * @return $this
     */
    public function extra(ParamConfigurator|array $value): static
    {
        $this->_usedProperties['extra'] = true;
        $this->extra = $value;

        return $this;
    }

    /**
     * Rate limiter name to use for throttling requests.
     * @default null
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function rateLimiter($value): static
    {
        $this->_usedProperties['rateLimiter'] = true;
        $this->rateLimiter = $value;

        return $this;
    }

    /**
     * @template TValue of mixed
     * @param TValue $value
     * @default {"enabled":false,"retry_strategy":null,"http_codes":[],"max_retries":3,"delay":1000,"multiplier":2,"max_delay":0,"jitter":0.1}
     * @return \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig|$this
     * @psalm-return (TValue is array ? \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig : static)
     */
    public function retryFailed(mixed $value = []): \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig|static
    {
        if (!\is_array($value)) {
            $this->_usedProperties['retryFailed'] = true;
            $this->retryFailed = $value;

            return $this;
        }

        if (!$this->retryFailed instanceof \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig) {
            $this->_usedProperties['retryFailed'] = true;
            $this->retryFailed = new \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig($value);
        } elseif (0 < \func_num_args()) {
            throw new InvalidConfigurationException('The node created by "retryFailed()" has already been initialized. You cannot pass values the second time you call retryFailed().');
        }

        return $this->retryFailed;
    }

    public function __construct(array $config = [])
    {
        if (array_key_exists('headers', $config)) {
            $this->_usedProperties['headers'] = true;
            $this->headers = $config['headers'];
            unset($config['headers']);
        }

        if (array_key_exists('vars', $config)) {
            $this->_usedProperties['vars'] = true;
            $this->vars = $config['vars'];
            unset($config['vars']);
        }

        if (array_key_exists('max_redirects', $config)) {
            $this->_usedProperties['maxRedirects'] = true;
            $this->maxRedirects = $config['max_redirects'];
            unset($config['max_redirects']);
        }

        if (array_key_exists('http_version', $config)) {
            $this->_usedProperties['httpVersion'] = true;
            $this->httpVersion = $config['http_version'];
            unset($config['http_version']);
        }

        if (array_key_exists('resolve', $config)) {
            $this->_usedProperties['resolve'] = true;
            $this->resolve = $config['resolve'];
            unset($config['resolve']);
        }

        if (array_key_exists('proxy', $config)) {
            $this->_usedProperties['proxy'] = true;
            $this->proxy = $config['proxy'];
            unset($config['proxy']);
        }

        if (array_key_exists('no_proxy', $config)) {
            $this->_usedProperties['noProxy'] = true;
            $this->noProxy = $config['no_proxy'];
            unset($config['no_proxy']);
        }

        if (array_key_exists('timeout', $config)) {
            $this->_usedProperties['timeout'] = true;
            $this->timeout = $config['timeout'];
            unset($config['timeout']);
        }

        if (array_key_exists('max_duration', $config)) {
            $this->_usedProperties['maxDuration'] = true;
            $this->maxDuration = $config['max_duration'];
            unset($config['max_duration']);
        }

        if (array_key_exists('bindto', $config)) {
            $this->_usedProperties['bindto'] = true;
            $this->bindto = $config['bindto'];
            unset($config['bindto']);
        }

        if (array_key_exists('verify_peer', $config)) {
            $this->_usedProperties['verifyPeer'] = true;
            $this->verifyPeer = $config['verify_peer'];
            unset($config['verify_peer']);
        }

        if (array_key_exists('verify_host', $config)) {
            $this->_usedProperties['verifyHost'] = true;
            $this->verifyHost = $config['verify_host'];
            unset($config['verify_host']);
        }

        if (array_key_exists('cafile', $config)) {
            $this->_usedProperties['cafile'] = true;
            $this->cafile = $config['cafile'];
            unset($config['cafile']);
        }

        if (array_key_exists('capath', $config)) {
            $this->_usedProperties['capath'] = true;
            $this->capath = $config['capath'];
            unset($config['capath']);
        }

        if (array_key_exists('local_cert', $config)) {
            $this->_usedProperties['localCert'] = true;
            $this->localCert = $config['local_cert'];
            unset($config['local_cert']);
        }

        if (array_key_exists('local_pk', $config)) {
            $this->_usedProperties['localPk'] = true;
            $this->localPk = $config['local_pk'];
            unset($config['local_pk']);
        }

        if (array_key_exists('passphrase', $config)) {
            $this->_usedProperties['passphrase'] = true;
            $this->passphrase = $config['passphrase'];
            unset($config['passphrase']);
        }

        if (array_key_exists('ciphers', $config)) {
            $this->_usedProperties['ciphers'] = true;
            $this->ciphers = $config['ciphers'];
            unset($config['ciphers']);
        }

        if (array_key_exists('peer_fingerprint', $config)) {
            $this->_usedProperties['peerFingerprint'] = true;
            $this->peerFingerprint = new \Symfony\Config\Framework\HttpClient\DefaultOptions\PeerFingerprintConfig($config['peer_fingerprint']);
            unset($config['peer_fingerprint']);
        }

        if (array_key_exists('crypto_method', $config)) {
            $this->_usedProperties['cryptoMethod'] = true;
            $this->cryptoMethod = $config['crypto_method'];
            unset($config['crypto_method']);
        }

        if (array_key_exists('extra', $config)) {
            $this->_usedProperties['extra'] = true;
            $this->extra = $config['extra'];
            unset($config['extra']);
        }

        if (array_key_exists('rate_limiter', $config)) {
            $this->_usedProperties['rateLimiter'] = true;
            $this->rateLimiter = $config['rate_limiter'];
            unset($config['rate_limiter']);
        }

        if (array_key_exists('retry_failed', $config)) {
            $this->_usedProperties['retryFailed'] = true;
            $this->retryFailed = \is_array($config['retry_failed']) ? new \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig($config['retry_failed']) : $config['retry_failed'];
            unset($config['retry_failed']);
        }

        if ($config) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($config)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['headers'])) {
            $output['headers'] = $this->headers;
        }
        if (isset($this->_usedProperties['vars'])) {
            $output['vars'] = $this->vars;
        }
        if (isset($this->_usedProperties['maxRedirects'])) {
            $output['max_redirects'] = $this->maxRedirects;
        }
        if (isset($this->_usedProperties['httpVersion'])) {
            $output['http_version'] = $this->httpVersion;
        }
        if (isset($this->_usedProperties['resolve'])) {
            $output['resolve'] = $this->resolve;
        }
        if (isset($this->_usedProperties['proxy'])) {
            $output['proxy'] = $this->proxy;
        }
        if (isset($this->_usedProperties['noProxy'])) {
            $output['no_proxy'] = $this->noProxy;
        }
        if (isset($this->_usedProperties['timeout'])) {
            $output['timeout'] = $this->timeout;
        }
        if (isset($this->_usedProperties['maxDuration'])) {
            $output['max_duration'] = $this->maxDuration;
        }
        if (isset($this->_usedProperties['bindto'])) {
            $output['bindto'] = $this->bindto;
        }
        if (isset($this->_usedProperties['verifyPeer'])) {
            $output['verify_peer'] = $this->verifyPeer;
        }
        if (isset($this->_usedProperties['verifyHost'])) {
            $output['verify_host'] = $this->verifyHost;
        }
        if (isset($this->_usedProperties['cafile'])) {
            $output['cafile'] = $this->cafile;
        }
        if (isset($this->_usedProperties['capath'])) {
            $output['capath'] = $this->capath;
        }
        if (isset($this->_usedProperties['localCert'])) {
            $output['local_cert'] = $this->localCert;
        }
        if (isset($this->_usedProperties['localPk'])) {
            $output['local_pk'] = $this->localPk;
        }
        if (isset($this->_usedProperties['passphrase'])) {
            $output['passphrase'] = $this->passphrase;
        }
        if (isset($this->_usedProperties['ciphers'])) {
            $output['ciphers'] = $this->ciphers;
        }
        if (isset($this->_usedProperties['peerFingerprint'])) {
            $output['peer_fingerprint'] = $this->peerFingerprint->toArray();
        }
        if (isset($this->_usedProperties['cryptoMethod'])) {
            $output['crypto_method'] = $this->cryptoMethod;
        }
        if (isset($this->_usedProperties['extra'])) {
            $output['extra'] = $this->extra;
        }
        if (isset($this->_usedProperties['rateLimiter'])) {
            $output['rate_limiter'] = $this->rateLimiter;
        }
        if (isset($this->_usedProperties['retryFailed'])) {
            $output['retry_failed'] = $this->retryFailed instanceof \Symfony\Config\Framework\HttpClient\DefaultOptions\RetryFailedConfig ? $this->retryFailed->toArray() : $this->retryFailed;
        }

        return $output;
    }

}
